package com.safari.implementasic;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

public class faktorial extends AppCompatActivity {

    EditText edt_input;
    TextView txt_hasil;
    Button btn_proses;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faktorial);

        edt_input = findViewById(R.id.ed_input);
        txt_hasil = findViewById(R.id.tx_hasil);
        btn_proses = findViewById(R.id.bt_proses);

        btn_proses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int angka_input = Integer.parseInt(edt_input.getText().toString());
                txt_hasil.setText(String.format(Locale.getDefault(),"%.2f",faktorial(angka_input)));
            }
        });




    }

    // 5 x 4 x 3 x2 x 1 = 120//

    private double faktorial (double n){
        if (n <= 1){
            return n;
        }
        else {
            return n * faktorial(n-1);
        }
    }

}